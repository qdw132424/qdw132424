% Application of simple limits/bounds
function result = Bounds(s,I,M,Ub,Lb)
     for m=1:M
        for n=1:I+M+1
            if s(m,n)>Ub(m,n)
               s(m,n)=Ub(m,n);
            end
            if s(m,n)<Lb(m,n)
               s(m,n)=Lb(m,n); 
            end
        end
     end
     result=s;
end