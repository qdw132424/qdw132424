%% ��ջ���
clear 
clc 
%��������
load extended_data
%% ����˵��
% ������p0~p6��b��c
%% ��������
w_max = 0.9;
w_min = 0.4;
% c1 = 2;       % ���ٳ���
% c2 = 2;       % ���ٳ���
C_s = 2.5;
C_e = 0.5;
S_s = 0.5;
S_e = 2.5;
SwarmSize = 50;     % ����Ⱥ��ģ
MaxIter = 50;      % ����������  
I=length(input_train(:,1));%�����ڵ���
M=2*I;%������ڵ���
Vmax = 0.1;
Vmin = -0.1;
Lb= 0*ones(M,I+M+1);    % ��������Lower limit/bounds/     a vector
Ub= zeros(M,I+M+1);     % ��������Upper limit/bounds/     a vector
Ub(:,1:I+1)=ones(M,I+1);
Ub(:,I+2:I+M+1)=2*ones(M,M);    

%ѡ����������������ݹ�һ��
[inputn,inputps]=mapminmax(input_train);
[outputn,outputps]=mapminmax(output_train);

% ���ݹ�һ��
% inputn_test=mapminmax(input_test,0,1);
% outputn_test=mapminmax(output_test,0,1);
% input_test=input_test(:,1:50);
% output_test=output_test(:,1:50);
%% ����Ⱥ��ʼ��
    Swarm=cell(1,SwarmSize);
    Range=cell(1,SwarmSize);
    VStep=cell(1,SwarmSize);
    for i=1:SwarmSize
       Range{1,i}=(Ub-Lb);
       Swarm{1,i}=rand(M,I+M+1).*Range{1,i};% ��ʼ������Ⱥ
       VStep{1,i}=rand(M,I+M+1)*(Vmax-Vmin) + Vmin;% ��ʼ���ٶ�
    end
    fSwarm = zeros(SwarmSize,1);
for i=1:SwarmSize
    [fSwarm(i,:),yn] = T_S_train(Swarm{1,i},I,M,input_train,output_train);                         % ����Ⱥ����Ӧֵ
end
[new_fSwarm,index]=sort(fSwarm);
%% ���ϴθ���ֵ����һ�θ���ֵ�����弫ֵ��Ⱥ�弫ֵ
[bestf , bestindex]=min(fSwarm);
gbest=Swarm{1,bestindex};   % ȫ�����
pbest=Swarm;                % ��ǰ�������
fpbest=fSwarm;              % ���������Ӧֵ
fgbest=bestf;               % ȫ�������Ӧֵ

%% ����Ѱ��
iter = 0;
PSO_RPE_fuzzy_ANN = zeros(1,MaxIter);
% S=zeros(MaxIter,1);
% A=zeros(MaxIter,SwarmSize);
% w_various=zeros(MaxIter,SwarmSize);
% L=2;c=0.5;  
tic 
for iter=1:MaxIter
%     S(iter)=fgbest/max(fSwarm);
%     A(iter,:)=fgbest/fSwarm;
%     w_various(iter,:)=(L-S(iter))*exp(-iter)*(A(iter,:)+c);
    Last_Swarm=Swarm;           % ��һ�θ���ֵ
    Last_Last_Swarm=Last_Swarm; % ����һ�θ���ֵ
    [worstf , worstindex]=max(fSwarm);
    Swarm{1,worstindex}=gbest;   % ��ȫ����ô���ȫ�����
    w_various = w_max - iter .* (w_max - w_min) ./ MaxIter;
    c1 = C_s + (( C_e - C_s ) ./ MaxIter) .* iter;
    c2 = S_s + (( S_e - S_s) ./ MaxIter) .* iter;
    for j=1:SwarmSize
        % �ٶȸ���
%         VStep{1,j} = w_various*VStep{1,j} + c1*rand*(pbest{1,j} - 2*Swarm{1,j}+Last_Swarm{1,j}) + c2*rand*(gbest - 2*Swarm{1,j}+Last_Swarm{1,j});
        VStep{1,j} = w_various*VStep{1,j} + c1*rand*(pbest{1,j} - 4*Swarm{1,j}+2*Last_Swarm{1,j}+Last_Last_Swarm{1,j}) + c2*rand*(gbest - 4*Swarm{1,j}+2*Last_Swarm{1,j}+Last_Last_Swarm{1,j});
        for m=1:M
            for n=1:M+I+1
                if VStep{1,j}(m,n)>Vmax 
                    VStep{1,j}(m,n)=Vmax; 
                end
                if VStep{1,j}(m,n)<Vmin 
                    VStep{1,j}(m,n)=Vmin; 
                end
            end
        end
        % λ�ø���
        Swarm{1,j}=Swarm{1,j}+VStep{1,j};
        Swarm{1,j} = Bounds(Swarm{1,j},I,M,Ub,Lb);
        % ��Ӧֵ
        [fSwarm(j,:),yn]=T_S_train(Swarm{1,j},I,M,input_train,output_train);
        % �������Ÿ���     
        if fSwarm(j) < fpbest(j)
            pbest{1,j} = Swarm{1,j};
            fpbest(j) = fSwarm(j);
        end
        % Ⱥ�����Ÿ���
        if fSwarm(j) < fgbest
            gbest = Swarm{1,j};
            fgbest = fSwarm(j);
        end
    end
    PSO_RPE_fuzzy_ANN(1,iter) = fgbest;
    disp(['Iteration ' num2str(iter) ': fzbest = ' num2str(PSO_RPE_fuzzy_ANN(iter))]);
end
toc
%% ��ͼ���
figure(1)      % ��������ָ��MSE�ı仯����
plot(PSO_RPE_fuzzy_ANN,'LineWidth',2)
xlabel('Iteration','fontsize',18);ylabel('fitness-value','fontsize',18);
set(gca,'Fontsize',18);

figure(2);
plot(outputn,'r')
hold on
plot(yn,'b')
hold on
plot(outputn-yn,'g');
legend('Actual output','Predictive output','error',12)
title('Training data prediction','fontsize',12)
xlabel('Sample number','fontsize',12)
ylabel('Water quality level','fontsize',12)
%% ���Խ��
[mse,err,output_test,test_simu]=T_S_test(gbest,I,M,input_test,output_test);
%% ȷ��ˮ�ʵȼ�
m = length(input_test);
output_test_value=zeros(m,1);
output_prediction_value=zeros(m,1);
[~,num]=size(output_train);
output_train_value=zeros(num,1);
for i=1:m
    if output_test(i)<=1.5
        output_test_value(i)=1;
    elseif output_test(i)>1.5&&output_test(i)<=2.5
        output_test_value(i)=2;
    elseif output_test(i)>2.5&&output_test(i)<=3.5
        output_test_value(i)=3;
    elseif output_test(i)>3.5&&output_test(i)<=4.5
        output_test_value(i)=4;
    else
        output_test_value(i)=5;
    end
end
for i=1:m
    if test_simu(i)<=1.5
        output_prediction_value(i)=1;
    elseif test_simu(i)>1.5&&test_simu(i)<=2.5
        output_prediction_value(i)=2;
    elseif test_simu(i)>2.5&&test_simu(i)<=3.5
        output_prediction_value(i)=3;
    elseif test_simu(i)>3.5&&test_simu(i)<=4.5
        output_prediction_value(i)=4;
    else
        output_prediction_value(i)=5;
    end
end
for i=1:num
    if output_train(i)<=1.5
        output_train_value(i)=1;
    elseif output_train(i)>1.5&&output_train(i)<=2.5
        output_train_value(i)=2;
    elseif output_train(i)>2.5&&output_train(i)<=3.5
        output_train_value(i)=3;
    elseif output_train(i)>3.5&&output_train(i)<=4.5
        output_train_value(i)=4;
    else
        output_train_value(i)=5;
    end
end
result=output_test_value-output_prediction_value;
%% ��ͼ
figure(3)
plot(output_test,'r')
hold on
plot(test_simu,'b')
hold on
plot(test_simu-output_test,'g')
legend('Actual output','Predictive output','error','fontsize',12)
title('Test data prediction','fontsize',12)
xlabel('Sample number','fontsize',12)
ylabel('Water quality level','fontsize',12)
%% �任
PSO_RPE_fuzzy_ANN = PSO_RPE_fuzzy_ANN';
actual_train = outputn';
pre_train = yn';
err_train = (outputn - yn)';
actual_test = output_test';
pre_test = test_simu';
err_test = (test_simu-output_test)';
%%
save PSO_RPE_data PSO_RPE_fuzzy_ANN actual_train pre_train err_train actual_test pre_test err_test
save Value output_test_value output_prediction_value output_train_value
