%% ���꽭ʵ��ˮ��Ԥ��
load  data2 hgsc gjhy dxg
tic
%-----------------------------------�칤ˮ��-----------------------------------
zssz=hgsc;
%���ݹ�һ��
inputn_test =mapminmax('apply',zssz,inputps);
[~,m]=size(zssz);

for k=1:1:m
    x=inputn_test(:,k);
        
    %��������м��
    for i=1:I
        for j=1:M
            u(i,j)=exp(-(x(i)-gbest(j,i+13))^2/gbest(j,i+7));
        end
    end
    
    for i=1:M
        w(i)=u(1,i)*u(2,i)*u(3,i)*u(4,i)*u(5,i)*u(6,i);
    end
                
    addw=0;
        
    for i=1:M   
        addw=addw+w(i);
    end
        
    for i=1:M   
        yi(i)=gbest(i,1)+gbest(i,2)*x(1)+gbest(i,3)*x(2)+gbest(i,4)*x(3)+gbest(i,5)*x(4)+gbest(i,6)*x(5)+gbest(i,7)*x(6);
    end
        
    addyw=0;        
    for i=1:M    
        addyw=addyw+yi(i)*w(i);        
    end
        
    %�������
    szzb(k)=addyw/addw;
end
szzbz1=mapminmax('reverse',szzb,outputps);

for i=1:m
    if szzbz1(i)<=1.5
        szpj1(i)=1;
    elseif szzbz1(i)>1.5&&szzbz1(i)<=2.5
        szpj1(i)=2;
    elseif szzbz1(i)>2.5&&szzbz1(i)<=3.5
        szpj1(i)=3;
    elseif szzbz1(i)>3.5&&szzbz1(i)<=4.5
        szpj1(i)=4;
    else
        szpj1(i)=5;
    end
end
% %-----------------------------------�߼һ�԰-----------------------------------
zssz=gjhy;
inputn_test =mapminmax('apply',zssz,inputps);
[n,m]=size(zssz);

for k=1:1:m
    x=inputn_test(:,k);
        
    %��������м��
    for i=1:I
        for j=1:M
            u(i,j)=exp(-(x(i)-gbest(j,i+13))^2/gbest(j,i+7));
        end
    end
    
    for i=1:M
        w(i)=u(1,i)*u(2,i)*u(3,i)*u(4,i)*u(5,i)*u(6,i);
    end
                
    addw=0;
        
    for i=1:M   
        addw=addw+w(i);
    end
        
    for i=1:M   
        yi(i)=gbest(i,1)+gbest(i,2)*x(1)+gbest(i,3)*x(2)+gbest(i,4)*x(3)+gbest(i,5)*x(4)+gbest(i,6)*x(5)+gbest(i,7)*x(6);
    end
        
    addyw=0;        
    for i=1:M    
        addyw=addyw+yi(i)*w(i);        
    end
        
    %�������
    szzb(k)=addyw/addw;
end
szzbz2=mapminmax('reverse',szzb,outputps);

for i=1:m
    if szzbz2(i)<=1.5
        szpj2(i)=1;
    elseif szzbz2(i)>1.5&&szzbz2(i)<=2.5
        szpj2(i)=2;
    elseif szzbz2(i)>2.5&&szzbz2(i)<=3.5
        szpj2(i)=3;
    elseif szzbz2(i)>3.5&&szzbz2(i)<=4.5
        szpj2(i)=4;
    else
        szpj2(i)=5;
    end
end
% %-----------------------------------��Ϫ��ˮ��-----------------------------------
zssz=dxg;
inputn_test =mapminmax('apply',zssz,inputps);
[n,m]=size(zssz);

for k=1:1:m
    x=inputn_test(:,k);
        
    %��������м��
    for i=1:I
        for j=1:M
            u(i,j)=exp(-(x(i)-gbest(j,i+13))^2/gbest(j,i+7));
        end
    end
    
    for i=1:M
        w(i)=u(1,i)*u(2,i)*u(3,i)*u(4,i)*u(5,i)*u(6,i);
    end
                
    addw=0;
        
    for i=1:M   
        addw=addw+w(i);
    end
        
    for i=1:M   
        yi(i)=gbest(i,1)+gbest(i,2)*x(1)+gbest(i,3)*x(2)+gbest(i,4)*x(3)+gbest(i,5)*x(4)+gbest(i,6)*x(5)+gbest(i,7)*x(6);        
    end
        
    addyw=0;        
    for i=1:M    
        addyw=addyw+yi(i)*w(i);        
    end
        
    %�������
    szzb(k)=addyw/addw;
end
szzbz3=mapminmax('reverse',szzb,outputps);

for i=1:m
    if szzbz3(i)<=1.5
        szpj3(i)=1;
    elseif szzbz3(i)>1.5&&szzbz3(i)<=2.5
        szpj3(i)=2;
    elseif szzbz3(i)>2.5&&szzbz3(i)<=3.5
        szpj3(i)=3;
    elseif szzbz3(i)>3.5&&szzbz3(i)<=4.5
        szpj3(i)=4;
    else
        szpj3(i)=5;
    end
end
toc
figure(3)
plot(szzbz1,'o-r')
hold on
plot(szzbz2,'*-g')
hold on
plot(szzbz3,'*:b')
xlabel('Time','fontsize',12)
ylabel('Forecast water quality','fontsize',12)
legend('hgsc','gjhy','dxg',12)
% xlabel('ʱ��','fontsize',12)
% ylabel('Ԥ��ˮ��','fontsize',12)
% legend('�칤ˮ��','�߼һ�԰ˮ��','��Ϫ��ˮ��','fontsize',12)
