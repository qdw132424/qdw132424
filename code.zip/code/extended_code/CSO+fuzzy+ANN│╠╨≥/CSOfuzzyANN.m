%%��ջ���
clear
clc
%��������
load extended_data
%load data1
%%��������
SwarmSize = 50;     % ����Ⱥ��ģ
MaxIter = 50;      % ����������  
I=length(input_train(:,1));%�����ڵ���
M=2*I;%������ڵ���
dim = I+M+1;    % Number of dimensions 
G = 10;     % How often the chicken swamr can be updated. The details of its meaning are illustrated at the following codes.         
rPercent = 0.2;    % Th e population size of roosters accounts for "rPercent" percent of the total population size
hPercent = 0.6;   % The population size of hens accounts for "hPercent" percent of the total population size
mPercent = 0.1;  % The population size of mother hens accounts for "mPercent" percent of the population size of hens                  
% end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
rNum = round( SwarmSize * rPercent );    % The population size of roosters
hNum = round( SwarmSize * hPercent );    % The population size of hens
cNum = SwarmSize - rNum - hNum;          % The population size of chicks
mNum = round( hNum * mPercent );   % The population size of mother hens

Lb= 0*ones(M,I+M+1);    % ��������Lower limit/bounds/     a vector
Ub= zeros(M,I+M+1);     % ��������Upper limit/bounds/     a vector
Ub(:,1:I+1)=ones(M,I+1);
Ub(:,I+2:I+M+1)=2*ones(M,M);     
CSO_fuzzy_ANN = zeros(1,MaxIter);

%ѡ����������������ݹ�һ��
[inputn,inputps]=mapminmax(input_train);
[outputn,outputps]=mapminmax(output_train);
%% ��Ⱥ��ʼ��
    Swarm=cell(1,SwarmSize);
    Range=cell(1,SwarmSize);
    for i=1:SwarmSize
       Range{1,i}=(Ub-Lb);
       Swarm{1,i}=rand(M,I+M+1).*Range{1,i};% ��ʼ������Ⱥ
    end
    fSwarm = zeros(SwarmSize,1);
for i=1:SwarmSize
    [fSwarm(i,:),yn] = T_S_train(Swarm{1,i},I,M,input_train,output_train);                         % ����Ⱥ����Ӧֵ
end
%% ���ϴθ���ֵ����һ�θ���ֵ�����弫ֵ��Ⱥ�弫ֵ
[bestf , bestindex]=min(fSwarm);
gbest=Swarm{1,bestindex};   % ȫ�����
pbest=Swarm;                % ��ǰ�������
fpbest=fSwarm;              % ���������Ӧֵ
fgbest=bestf;               % ȫ�������Ӧֵ
% Start the iteration.����ʼ
tic;
for iter = 1 : MaxIter
    % This parameter is to describe how the chicks would follow their mother to forage for food.
    FL = rand( SwarmSize, 1 ) .* 0.6 + 0.4;  % In fact, there exist cNum chicks, thus only cNum values of FL would be used.
    if( mod( iter, G ) == 1 )   
        [ ~, sortIndex ] = sort( fSwarm );     % Here ans would be unused. Only sortIndex is useful.
        motherLib = randperm( hNum, mNum ) + rNum;   % Randomly select which mNum hens would be the mother hens.
        mate = randi( rNum, hNum, 1 );     % randomly select each hen's mate, rooster.
        mother = motherLib( randi( mNum, cNum, 1 ) );  % randomly select cNum chicks' mother hens
    end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%   
    for i = 1 : rNum                                                      % Update the rNum roosters' values. 
        anotherRooster = randiTabu( 1, rNum, i, 1 );  % randomly select another rooster different from the i (th) chicken.
        if( fpbest( sortIndex( i ) ) <= fpbest( sortIndex( anotherRooster ) ) )
            tempSigma = 1;
        else
            tempSigma = exp( ( fpbest( sortIndex( anotherRooster ) ) - fpbest( sortIndex( i ) ) ) / abs( fpbest( sortIndex( i ) ) + 1e-50 ) );
        end
        Swarm{1,sortIndex( i )}=pbest{1,sortIndex( i )}.*( 1 + tempSigma .* randn( 12, dim ) );
        Swarm{1,sortIndex( i )} = Bounds(Swarm{1,sortIndex( i )},I,M,Ub,Lb);
        [fSwarm(sortIndex( i ),:),yn] = T_S_train(Swarm{1,sortIndex( i )},I,M,input_train,output_train); 
    end
    
    for i = ( rNum + 1 ) : ( rNum + hNum )                     % Update the hNum hens' values. 
        other = randiTabu( 1,  i,  mate( i - rNum ), 1 );  % randomly select another chicken different from the i (th) chicken's mate.
        c1 = exp( ( fpbest( sortIndex( i ) ) - fpbest( sortIndex( mate( i - rNum ) ) ) ) / abs( fpbest( sortIndex( i ) ) + 1e-50 ) );
        c2 = exp( ( -fpbest( sortIndex( i ) ) + fpbest( sortIndex( other ) ) ) );
        if (c2==inf)
            c2=100000;
        end
        Swarm{1,sortIndex( i )}=pbest{1,sortIndex( i )}+(pbest{1,sortIndex(mate(i - rNum))}-pbest{1,sortIndex(i)}) .* c1 .* rand(12, dim) +...
            (pbest{1,sortIndex(other)}-pbest{1,sortIndex( i )}).* c2 .* rand(12, dim);
        Swarm{1,sortIndex( i )} = Bounds(Swarm{1,sortIndex( i )},I,M,Ub,Lb);
        [fSwarm(sortIndex( i ),:),yn] = T_S_train(Swarm{1,sortIndex( i )},I,M,input_train,output_train); 
    end
    
    for i = ( rNum + hNum + 1 ) : SwarmSize                           % Update the cNum chicks' values.
        Swarm{1,sortIndex(i)}=pbest{1,sortIndex(i)}+( pbest{1,sortIndex(mother(i-rNum-hNum))} - pbest{1,sortIndex(i)}) .* FL( i );
        Swarm{1,sortIndex( i )} = Bounds(Swarm{1,sortIndex( i )},I,M,Ub,Lb);
        [fSwarm(sortIndex( i ),:),yn] = T_S_train(Swarm{1,sortIndex( i )},I,M,input_train,output_train); 
    end
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
   % Update the individual's best fitness vlaue and the global best fitness value
   
    for i = 1 : SwarmSize 
        if ( fSwarm(i) < fpbest(i))
            fpbest( i ) = fSwarm( i );
            pbest{1,i}= Swarm{1,i};
        end
        
        if( fpbest(i) < fgbest )
            fgbest = fpbest(i);
            gbest = pbest{1,i};
        end
    end
    CSO_fuzzy_ANN(1,iter) = fgbest;
    disp(['Iteration ' num2str(iter) ': fzbest = ' num2str(CSO_fuzzy_ANN(iter))]);
end
toc
%% ��ͼ���
figure(1)      % ��������ָ��MSE�ı仯����
plot(CSO_fuzzy_ANN,'LineWidth',2)
xlabel('Iteration','fontsize',18);ylabel('fitness-value','fontsize',18);
set(gca,'Fontsize',18);

figure(2);
plot(outputn,'r')
hold on
plot(yn,'b')
hold on
plot(outputn-yn,'g');
legend('Actual output','Predictive output','error','fontsize',12)
title('Training data prediction','fontsize',12)
xlabel('Sample number','fontsize',12)
ylabel('Water quality level','fontsize',12)
%% ���Խ��
[mse,err,output_test,test_simu]=T_S_test(gbest,I,M,input_test,output_test);
%% ȷ��ˮ�ʵȼ�
output_test_value=zeros(M,1);
output_prediction_value=zeros(M,1);
[~,num]=size(output_train);
output_train_value=zeros(num,1);
for i=1:M
    if output_test(i)<=1.5
        output_test_value(i)=1;
    elseif output_test(i)>1.5&&output_test(i)<=2.5
        output_test_value(i)=2;
    elseif output_test(i)>2.5&&output_test(i)<=3.5
        output_test_value(i)=3;
    elseif output_test(i)>3.5&&output_test(i)<=4.5
        output_test_value(i)=4;
    else
        output_test_value(i)=5;
    end
end
for i=1:M
    if test_simu(i)<=1.5
        output_prediction_value(i)=1;
    elseif test_simu(i)>1.5&&test_simu(i)<=2.5
        output_prediction_value(i)=2;
    elseif test_simu(i)>2.5&&test_simu(i)<=3.5
        output_prediction_value(i)=3;
    elseif test_simu(i)>3.5&&test_simu(i)<=4.5
        output_prediction_value(i)=4;
    else
        output_prediction_value(i)=5;
    end
end
for i=1:num
    if output_train(i)<=1.5
        output_train_value(i)=1;
    elseif output_train(i)>1.5&&output_train(i)<=2.5
        output_train_value(i)=2;
    elseif output_train(i)>2.5&&output_train(i)<=3.5
        output_train_value(i)=3;
    elseif output_train(i)>3.5&&output_train(i)<=4.5
        output_train_value(i)=4;
    else
        output_train_value(i)=5;
    end
end
result=output_test_value-output_prediction_value;
%% ��ͼ
figure(3)
plot(output_test,'r')
hold on
plot(test_simu,'b')
hold on
plot(test_simu-output_test,'g')
legend('Actual output','Predictive output','error','fontsize',12)
title('Test data prediction','fontsize',12)
xlabel('Sample number','fontsize',12)
ylabel('Water quality level','fontsize',12)
%% �任
CSO_fuzzy_ANN = CSO_fuzzy_ANN';
actual_train = outputn';
pre_train = yn';
err_train = (outputn - yn)';
actual_test = output_test';
pre_test = test_simu';
err_test = (test_simu-output_test)';
%%
save CSO_data CSO_fuzzy_ANN actual_train pre_train err_train actual_test pre_test err_test
%save CSO_data gbest fgbest mse
save Value output_test_value output_prediction_value output_train_value